﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    float speed = 7.0f;
    public GameObject CoinCount;
    private int coins;

    // Start is called before the first frame update
    void Start()
    {
        CoinCount.GetComponent<Text>().text = "Coins Collected: " + coins;
    }

    // Update is called once per frame
    void Update()
    {
        coins = GameObject.FindGameObjectsWithTag("Coin").Length;
        CoinCount.GetComponent<Text>().text = "Coins Collected: " + coins;

        if (coins <= 0)
        {
            Debug.Log("Going to WinScene");
            SceneManager.LoadScene("WinScene");
        }

        if (transform.position.y < -5)
        {
            Debug.Log("Going to LoseScene");
            SceneManager.LoadScene("LoseScene");
        }

        if (Input.GetKey(KeyCode.W))
        {
            transform.position += transform.forward * speed * Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.S))
        {
            transform.position += transform.forward * -speed * Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.A))
        {
            transform.position += transform.right * -speed * Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.D))
        {
            transform.position += transform.right * speed * Time.deltaTime;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Coin")
        {
            Debug.Log("Coin Collected");
            Destroy(other.gameObject);
            CoinCount.GetComponent<Text>().text = "Coins Collected: " + coins;
        }
    }
}
